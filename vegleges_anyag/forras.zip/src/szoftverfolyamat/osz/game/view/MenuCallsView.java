package szoftverfolyamat.osz.game.view;

/*
 [view <--- menu]   
*/
public interface MenuCallsView {
    void resizePanel(int dx, int dy);
}


