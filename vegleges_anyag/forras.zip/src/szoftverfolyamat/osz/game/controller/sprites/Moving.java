package szoftverfolyamat.osz.game.controller.sprites;

import java.awt.Dimension;

public interface Moving {
    Dimension getTranslationVector();
}
