package szoftverfolyamat.osz.game.controller.sprites;

public interface AbstractSprite extends BoundingShape {
    void setBoundingShapeObserver(BoundingShapeObserver o);
} 

