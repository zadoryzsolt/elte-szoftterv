package szoftverfolyamat.osz.game.controller.sprites;

public interface AllowsCollision {
}