package szoftverfolyamat.osz.game.controller.sprites;

import javax.swing.ImageIcon;

public interface BitmapSprite {
    ImageIcon[] getIcons();
}
