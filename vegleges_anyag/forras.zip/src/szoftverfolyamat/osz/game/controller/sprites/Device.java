package szoftverfolyamat.osz.game.controller.sprites;

public interface Device extends AbstractSprite, AllowsCollision {
    void activate();
}
