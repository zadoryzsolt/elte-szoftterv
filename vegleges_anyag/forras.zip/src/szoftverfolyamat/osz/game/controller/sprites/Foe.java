package szoftverfolyamat.osz.game.controller.sprites;

public interface Foe {
    boolean instantlyKills();
    
    int scoreDecrease();
}
