package szoftverfolyamat.osz.game.controller.sprites;

public interface Resizable {
}