package szoftverfolyamat.osz.game.controller.sprites;

public interface Animated  {
    int getNextFrame();
}

