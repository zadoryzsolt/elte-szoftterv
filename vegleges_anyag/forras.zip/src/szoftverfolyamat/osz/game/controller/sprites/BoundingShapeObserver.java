package szoftverfolyamat.osz.game.controller.sprites;

public interface BoundingShapeObserver {
    void changed(BoundingShape s);
}

